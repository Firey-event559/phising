<?php

$username = "root";
$password = "";

$db = new PDO('mysql:host=localhost;dbname=phising', $username, $password);




?>